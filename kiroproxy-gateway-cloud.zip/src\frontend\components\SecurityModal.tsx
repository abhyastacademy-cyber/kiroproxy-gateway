import React, { useState } from 'react';
import { Lock, Key, Check, X } from 'lucide-react';

interface SecurityModalProps {
  isOpen: boolean;
  onClose: () => void;
  adminToken: string;
  onSaveToken: (token: string) => void;
}

export const SecurityModal: React.FC<SecurityModalProps> = ({
  isOpen,
  onClose,
  adminToken,
  onSaveToken,
}) => {
  const [tokenInput, setTokenInput] = useState(adminToken);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveToken(tokenInput.trim());
    onClose();
  };

  const handleClear = () => {
    setTokenInput('');
    onSaveToken('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-[#0f0f12] border border-[#27272a] rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#141417] text-[#fafafa] border border-[#27272a] flex items-center justify-center">
            <Lock className="w-5 h-5 text-[#fafafa]" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#fafafa]">Gateway Security Guard</h3>
            <p className="text-xs text-zinc-400 font-mono">PROXY_ADMIN_TOKEN Authorization</p>
          </div>
        </div>

        <p className="text-xs text-zinc-300 leading-relaxed">
          When this gateway is hosted on an AI Studio or Cloud Run public domain, protect administrative endpoints (<code className="text-[#fafafa] font-mono">/api/config</code>) and upstream invocations by configuring an authorization token.
        </p>

        <div>
          <label className="block text-xs font-medium text-zinc-400 mb-1">
            Admin Auth Token (Stored locally in browser localStorage)
          </label>
          <div className="relative">
            <input
              type="text"
              value={tokenInput}
              onChange={(e) => setTokenInput(e.target.value)}
              placeholder="e.g. secret_admin_token_123"
              className="w-full bg-[#09090b] border border-[#27272a] rounded-xl px-3 py-2 text-xs font-mono text-[#fafafa] focus:outline-none focus:border-[#fafafa] pr-10"
            />
            <Key className="w-4 h-4 text-zinc-500 absolute right-3 top-2.5 pointer-events-none" />
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-[#09090b] border border-[#27272a] text-[11px] text-zinc-400 space-y-1.5 font-mono">
          <p className="font-semibold text-zinc-300">How clients authenticate with this token:</p>
          <p>• Kiro IDE: Auto-routed via <code className="text-emerald-400">/k/&lt;token&gt;/generateAssistantResponse</code></p>
          <p>• HTTP APIs: Pass header <code className="text-emerald-400">Authorization: Bearer &lt;token&gt;</code></p>
        </div>

        <div className="flex items-center justify-end gap-2 pt-2">
          {adminToken && (
            <button
              onClick={handleClear}
              className="px-3 py-1.5 rounded-lg bg-[#141417] text-rose-400 hover:bg-rose-950/40 text-xs font-medium border border-[#27272a] hover:border-rose-500/30 transition-colors cursor-pointer"
            >
              Clear Token
            </button>
          )}
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-lg bg-[#141417] hover:bg-[#1c1c21] text-zinc-300 text-xs font-medium border border-[#27272a] transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-1.5 rounded-lg bg-[#fafafa] hover:bg-[#e4e4e7] text-[#09090b] text-xs font-semibold shadow-sm transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Check className="w-3.5 h-3.5 text-[#09090b]" />
            <span>Save Token</span>
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Layers,
  Plus,
  Trash2,
  Edit2,
  Check,
  ArrowUp,
  ArrowDown,
  Globe,
  Key,
  Shield,
  Zap,
  Save,
  AlertCircle,
  RotateCcw,
  ExternalLink,
} from 'lucide-react';
import type { GatewayConfig, CustomProvider } from '../types.js';

interface ProvidersTabProps {
  config: GatewayConfig | null;
  onSaveConfig: (updated: Partial<GatewayConfig>) => Promise<boolean>;
  isSaving: boolean;
}

const DEFAULT_7_TIERS = [
  'kilo',
  'cline',
  'openrouter',
  'orcarouter',
  'gemini',
  'custom',
  'canvas',
];

const TIER_METADATA: Record<string, { name: string; desc: string; badge: string }> = {
  kilo: {
    name: 'KILO',
    desc: 'Zero-Key Kilo 177+ Free Models Pool',
    badge: 'Tier 1',
  },
  cline: {
    name: 'CLINE',
    desc: 'Cline Autonomous Coding Multi-Model Pool',
    badge: 'Tier 2',
  },
  openrouter: {
    name: 'OPENROUTER',
    desc: 'Multi-Model Fallback & Rotation',
    badge: 'Tier 3',
  },
  orcarouter: {
    name: 'ORCAROUTER',
    desc: 'High-Throughput Free Inference Gateway',
    badge: 'Tier 4',
  },
  gemini: {
    name: 'GEMINI',
    desc: 'Google Gemini Direct API (Official Keys)',
    badge: 'Tier 5',
  },
  custom: {
    name: 'CUSTOM',
    desc: 'Custom Multi-Endpoint Failover Chain',
    badge: 'Tier 6',
  },
  canvas: {
    name: 'CANVAS',
    desc: 'Gemini Canvas Cloud Bridge (Zero Cost)',
    badge: 'Tier 7',
  },
};

function normalizeTiers(tiers?: string[]): string[] {
  if (!tiers || tiers.length === 0) return [...DEFAULT_7_TIERS];
  const normalized = tiers.map((t) => t.toLowerCase().trim()).filter(Boolean);
  // Ensure all 7 tiers are included
  const result = [...normalized];
  for (const t of DEFAULT_7_TIERS) {
    if (!result.includes(t)) {
      result.push(t);
    }
  }
  return result;
}

export const ProvidersTab: React.FC<ProvidersTabProps> = ({
  config,
  onSaveConfig,
  isSaving,
}) => {
  const [priorityOrder, setPriorityOrder] = useState<string[]>(() =>
    normalizeTiers(config?.providerPriorityOrder)
  );
  const [customProviders, setCustomProviders] = useState<CustomProvider[]>(
    config?.customProviders || []
  );

  // Edit / Add modal state
  const [editingProvider, setEditingProvider] = useState<CustomProvider | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [testResult, setTestResult] = useState<{ id: string; status: 'testing' | 'success' | 'error'; message: string } | null>(null);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState(false);

  // Keep local state in sync when config loads
  React.useEffect(() => {
    if (config) {
      setPriorityOrder(normalizeTiers(config.providerPriorityOrder));
      setCustomProviders(config.customProviders || []);
    }
  }, [config]);

  // Priority order manipulation
  const moveTier = (index: number, direction: 'up' | 'down') => {
    const newOrder = [...priorityOrder];
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= newOrder.length) return;

    const temp = newOrder[index];
    newOrder[index] = newOrder[targetIdx];
    newOrder[targetIdx] = temp;
    setPriorityOrder(newOrder);
  };

  const handleResetDefaultTiers = () => {
    setPriorityOrder([...DEFAULT_7_TIERS]);
  };

  const handleSaveAll = async () => {
    const success = await onSaveConfig({
      providerPriorityOrder: priorityOrder,
      customProviders,
    });
    if (success) {
      setSaveSuccessMsg(true);
      setTimeout(() => setSaveSuccessMsg(false), 3000);
    }
  };

  // Provider CRUD
  const handleToggleProvider = (id: string) => {
    setCustomProviders((prev) =>
      prev.map((p) => (p.id === id ? { ...p, enabled: !p.enabled } : p))
    );
  };

  const handleDeleteProvider = (id: string) => {
    if (confirm('Delete this custom provider configuration?')) {
      setCustomProviders((prev) => prev.filter((p) => p.id !== id));
    }
  };

  const handleSaveModal = (provider: CustomProvider) => {
    if (isCreating) {
      setCustomProviders((prev) => [...prev, provider]);
    } else {
      setCustomProviders((prev) =>
        prev.map((p) => (p.id === provider.id ? provider : p))
      );
    }
    setEditingProvider(null);
    setIsCreating(false);
  };

  const testProviderEndpoint = async (provider: CustomProvider) => {
    setTestResult({ id: provider.id, status: 'testing', message: 'Testing endpoint connectivity...' });
    const url = provider.baseUrls[0];
    if (!url) {
      setTestResult({ id: provider.id, status: 'error', message: 'No base URL specified.' });
      return;
    }

    try {
      const testUrl = url.endsWith('/v1') ? `${url}/models` : `${url}/v1/models`;
      const res = await fetch(testUrl, {
        headers: provider.apiKeys[0] ? { Authorization: `Bearer ${provider.apiKeys[0]}` } : {},
      });
      if (res.ok || res.status === 404 || res.status === 401) {
        setTestResult({
          id: provider.id,
          status: 'success',
          message: `Endpoint reachable (HTTP ${res.status}).`,
        });
      } else {
        setTestResult({
          id: provider.id,
          status: 'error',
          message: `Endpoint returned HTTP ${res.status}`,
        });
      }
    } catch (err: any) {
      setTestResult({
        id: provider.id,
        status: 'error',
        message: err.message || 'Connection failed',
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with Save Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-[#0f0f12] border border-[#27272a]">
        <div>
          <h2 className="text-xl font-bold text-[#fafafa] flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#fafafa]" />
            Provider Priority &amp; 7-Tier Failover
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Configure automated failover order: if an upstream provider hits rate limits (429) or times out (500), the gateway shifts to the next tier in real time.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {saveSuccessMsg && (
            <span className="text-xs text-emerald-400 font-medium flex items-center gap-1">
              <Check className="w-3.5 h-3.5" /> Saved
            </span>
          )}
          <button
            onClick={handleSaveAll}
            disabled={isSaving}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#fafafa] hover:bg-[#e4e4e7] text-[#09090b] text-xs font-semibold shadow-sm transition-all disabled:opacity-50 cursor-pointer"
          >
            <Save className="w-4 h-4 text-[#09090b]" />
            <span>{isSaving ? 'Saving Changes...' : 'Save & Persist Configuration'}</span>
          </button>
        </div>
      </div>

      {/* 7-Tier Order Card */}
      <div className="p-6 rounded-2xl bg-[#0f0f12] border border-[#27272a] space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-[#fafafa] uppercase tracking-wider flex items-center gap-2">
              <span>7-Tier Priority Cascade Order</span>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-[#141417] text-zinc-300 border border-[#27272a]">
                {priorityOrder.length} Tiers Active
              </span>
            </h3>
            <p className="text-xs text-zinc-400 mt-0.5">
              Reorder all 7 tiers using the up/down arrows. Tier 1 is attempted first; subsequent tiers are invoked sequentially upon 429/500 errors.
            </p>
          </div>
          <button
            onClick={handleResetDefaultTiers}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#141417] hover:bg-[#1c1c21] text-zinc-300 text-xs font-medium border border-[#27272a] transition-colors cursor-pointer"
            title="Reset to recommended standard order (KILO → CLINE → OPENROUTER → ORCAROUTER → GEMINI → CUSTOM → CANVAS)"
          >
            <RotateCcw className="w-3.5 h-3.5 text-zinc-400" />
            <span>Standard Order</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {priorityOrder.map((tierKey, idx) => {
            const meta = TIER_METADATA[tierKey.toLowerCase()] || {
              name: tierKey.toUpperCase(),
              desc: 'Configured Provider Tier',
              badge: `Tier ${idx + 1}`,
            };
            const isCanvas = tierKey.toLowerCase() === 'canvas';

            return (
              <div
                key={tierKey}
                className={`p-4 rounded-xl bg-[#141417] border transition-all flex flex-col justify-between ${
                  isCanvas ? 'border-[#3f3f46]' : 'border-[#27272a] hover:border-[#3f3f46]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-md bg-[#27272a] text-[#fafafa] text-xs font-mono font-bold flex items-center justify-center">
                        {idx + 1}
                      </span>
                      <span className="text-xs font-bold text-[#fafafa] tracking-wide uppercase font-mono">
                        {meta.name}
                      </span>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#09090b] text-zinc-400 border border-[#27272a]">
                      {meta.badge}
                    </span>
                  </div>

                  <p className="text-xs text-zinc-300 leading-snug min-h-[32px]">
                    {meta.desc}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-3 mt-2 border-t border-[#27272a]">
                  <span className="text-[10px] text-zinc-500 font-mono">
                    Priority {idx + 1} of {priorityOrder.length}
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => moveTier(idx, 'up')}
                      disabled={idx === 0}
                      className="p-1 rounded bg-[#09090b] text-zinc-400 hover:text-white disabled:opacity-30 transition-colors border border-[#27272a] cursor-pointer"
                      title="Move Priority Up"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => moveTier(idx, 'down')}
                      disabled={idx === priorityOrder.length - 1}
                      className="p-1 rounded bg-[#09090b] text-zinc-400 hover:text-white disabled:opacity-30 transition-colors border border-[#27272a] cursor-pointer"
                      title="Move Priority Down"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Custom Providers Section */}
      <div className="p-6 rounded-2xl bg-[#0f0f12] border border-[#27272a] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-[#fafafa] flex items-center gap-2">
              <Globe className="w-4 h-4 text-[#fafafa]" />
              Custom Providers (Multi-Endpoint Failover Lists)
            </h3>
            <p className="text-xs text-zinc-400 mt-0.5">
              Each custom provider supports a failover list of baseUrls that are tried sequentially if an endpoint goes down, plus API key rotation.
            </p>
          </div>
          <button
            onClick={() => {
              setIsCreating(true);
              setEditingProvider({
                id: 'custom-' + Date.now(),
                name: 'New Custom Provider',
                baseUrls: ['https://openrouter.ai/api/v1'],
                apiKeys: [''],
                activeModel: 'openai/gpt-4o',
                enabled: true,
                notes: '',
              });
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#fafafa] text-[#09090b] text-xs font-semibold hover:bg-[#e4e4e7] transition-colors self-start sm:self-auto cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 text-[#09090b]" />
            <span>Add Custom Provider</span>
          </button>
        </div>

        {/* Provider Cards */}
        {customProviders.length === 0 ? (
          <div className="py-8 text-center text-xs text-zinc-500 border border-dashed border-[#27272a] rounded-xl bg-[#09090b]">
            No custom providers configured yet. Click &quot;Add Custom Provider&quot; to configure OpenRouter, local Ollama, vLLM, or private proxy endpoints.
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-3">
            {customProviders.map((cp) => (
              <div
                key={cp.id}
                className={`p-4 rounded-xl border transition-all ${
                  cp.enabled
                    ? 'bg-[#141417] border-[#27272a] hover:border-[#3f3f46]'
                    : 'bg-[#0f0f12] border-[#27272a] opacity-60'
                }`}
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-[#fafafa] text-sm">{cp.name}</span>
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                          cp.enabled
                            ? 'bg-[#141417] text-emerald-400 border border-emerald-500/30'
                            : 'bg-[#141417] text-zinc-500 border border-[#27272a]'
                        }`}
                      >
                        {cp.enabled ? 'Enabled' : 'Disabled'}
                      </span>
                      {cp.activeModel && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-[#09090b] text-zinc-300 border border-[#27272a]">
                          {cp.activeModel}
                        </span>
                      )}
                    </div>
                    {cp.notes && <p className="text-xs text-zinc-400">{cp.notes}</p>}
                    <div className="flex flex-wrap items-center gap-2 pt-1 text-xs text-zinc-400 font-mono">
                      <span className="text-zinc-500">Endpoints ({cp.baseUrls.length}):</span>
                      {cp.baseUrls.map((url, uidx) => (
                        <span key={uidx} className="bg-[#09090b] px-2 py-0.5 rounded border border-[#27272a] text-zinc-300">
                          {url}
                        </span>
                      ))}
                      {cp.apiKeys && cp.apiKeys.length > 0 && (
                        <span className="text-zinc-500 ml-2">
                          Keys: {cp.apiKeys.filter(Boolean).length}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end md:self-auto">
                    <button
                      onClick={() => testProviderEndpoint(cp)}
                      className="px-2.5 py-1 rounded bg-[#09090b] hover:bg-[#1c1c21] text-zinc-300 text-xs transition-colors flex items-center gap-1 border border-[#27272a] cursor-pointer"
                    >
                      <Zap className="w-3 h-3 text-amber-400" />
                      <span>Test Ping</span>
                    </button>
                    <button
                      onClick={() => handleToggleProvider(cp.id)}
                      className="px-2.5 py-1 rounded bg-[#09090b] hover:bg-[#1c1c21] text-zinc-300 text-xs transition-colors border border-[#27272a] cursor-pointer"
                    >
                      {cp.enabled ? 'Disable' : 'Enable'}
                    </button>
                    <button
                      onClick={() => {
                        setIsCreating(false);
                        setEditingProvider({ ...cp });
                      }}
                      className="p-1.5 rounded bg-[#09090b] hover:bg-[#1c1c21] text-zinc-300 transition-colors border border-[#27272a] cursor-pointer"
                      title="Edit Provider"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeleteProvider(cp.id)}
                      className="p-1.5 rounded bg-[#09090b] hover:bg-rose-950/40 text-rose-400 transition-colors border border-[#27272a] hover:border-rose-500/30 cursor-pointer"
                      title="Delete Provider"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {testResult?.id === cp.id && (
                  <div
                    className={`mt-3 p-2.5 rounded-lg text-xs flex items-center gap-2 border font-mono ${
                      testResult.status === 'success'
                        ? 'bg-[#141417] border-emerald-500/30 text-emerald-300'
                        : testResult.status === 'error'
                        ? 'bg-[#141417] border-rose-500/30 text-rose-300'
                        : 'bg-[#141417] border-[#3f3f46] text-zinc-300'
                    }`}
                  >
                    <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>{testResult.message}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Upstream Failover Instructions Callout */}
      <div className="p-6 rounded-2xl bg-[#0f0f12] border border-[#27272a] space-y-3">
        <h3 className="text-sm font-bold text-[#fafafa] flex items-center gap-2">
          <Zap className="w-4 h-4 text-[#fafafa]" />
          Using This Cloud Gateway As an Upstream Failover Endpoint
        </h3>
        <p className="text-xs text-zinc-300 leading-relaxed">
          If you already run a local KiroProxy instance on your development machine (at <code className="text-[#fafafa] font-mono">http://localhost:8084</code>),
          you can add this published domain as a seamless upstream cloud fallback:
        </p>
        <div className="p-4 bg-[#09090b] rounded-xl border border-[#27272a] text-xs space-y-1.5 font-mono text-zinc-300">
          <p className="text-zinc-500">// In your local KiroProxy GUI (http://localhost:8084/config):</p>
          <p>1. Go to Custom Providers → Add Provider &quot;Cloud-Gateway-Fallback&quot;</p>
          <p>2. Set Base URL: <span className="text-emerald-400">{config?.detectedPublicUrl || (typeof window !== 'undefined' && (window.location.hostname.includes('ai.studio') || window.location.hostname.includes('run.app')) ? 'https://kiroproxy-746899042471.asia-southeast1.run.app' : window.location.origin)}/v1</span></p>
          <p>3. If PROXY_ADMIN_TOKEN is active, provide your token in the API Key field.</p>
        </div>
      </div>

      {/* Edit / Add Modal */}
      {editingProvider && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-[#0f0f12] border border-[#27272a] rounded-2xl w-full max-w-xl p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-[#fafafa]">
              {isCreating ? 'Add Custom Provider' : 'Edit Custom Provider'}
            </h3>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block text-zinc-400 mb-1 font-medium">Provider Name</label>
                <input
                  type="text"
                  value={editingProvider.name}
                  onChange={(e) => setEditingProvider({ ...editingProvider, name: e.target.value })}
                  className="w-full bg-[#09090b] border border-[#27272a] rounded-lg px-3 py-2 text-[#fafafa] focus:outline-none focus:border-[#fafafa] font-sans"
                  placeholder="e.g. OpenRouter Primary"
                />
              </div>

              <div>
                <label className="block text-zinc-400 mb-1 font-medium">
                  Base URLs (Failover Chain - One per line)
                </label>
                <textarea
                  rows={3}
                  value={editingProvider.baseUrls.join('\n')}
                  onChange={(e) =>
                    setEditingProvider({
                      ...editingProvider,
                      baseUrls: e.target.value.split('\n').map((s) => s.trim()).filter(Boolean),
                    })
                  }
                  className="w-full bg-[#09090b] border border-[#27272a] rounded-lg px-3 py-2 text-[#fafafa] font-mono focus:outline-none focus:border-[#fafafa]"
                  placeholder="https://openrouter.ai/api/v1&#10;https://backup-endpoint.ai/v1"
                />
                <span className="text-[11px] text-zinc-500">
                  First URL is tried first; if it returns 429 or fails, the gateway automatically shifts to line 2.
                </span>
              </div>

              <div>
                <label className="block text-zinc-400 mb-1 font-medium">
                  API Keys (Rotation Pool - One per line)
                </label>
                <textarea
                  rows={2}
                  value={editingProvider.apiKeys.join('\n')}
                  onChange={(e) =>
                    setEditingProvider({
                      ...editingProvider,
                      apiKeys: e.target.value.split('\n').map((s) => s.trim()).filter(Boolean),
                    })
                  }
                  className="w-full bg-[#09090b] border border-[#27272a] rounded-lg px-3 py-2 text-[#fafafa] font-mono focus:outline-none focus:border-[#fafafa]"
                  placeholder="sk-or-v1-..."
                />
                <span className="text-[11px] text-zinc-500">
                  Multiple keys will be rotated sequentially on quota depletion.
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-400 mb-1 font-medium">Default Model ID</label>
                  <input
                    type="text"
                    value={editingProvider.activeModel || ''}
                    onChange={(e) => setEditingProvider({ ...editingProvider, activeModel: e.target.value })}
                    className="w-full bg-[#09090b] border border-[#27272a] rounded-lg px-3 py-2 text-[#fafafa] font-mono focus:outline-none focus:border-[#fafafa]"
                    placeholder="anthropic/claude-3.5-sonnet"
                  />
                </div>
                <div>
                  <label className="block text-zinc-400 mb-1 font-medium">Notes / Description</label>
                  <input
                    type="text"
                    value={editingProvider.notes || ''}
                    onChange={(e) => setEditingProvider({ ...editingProvider, notes: e.target.value })}
                    className="w-full bg-[#09090b] border border-[#27272a] rounded-lg px-3 py-2 text-[#fafafa] focus:outline-none focus:border-[#fafafa]"
                    placeholder="High throughput tier"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-4 border-t border-[#27272a]">
              <button
                onClick={() => setEditingProvider(null)}
                className="px-4 py-2 rounded-xl bg-[#141417] hover:bg-[#1c1c21] text-zinc-300 text-xs font-medium border border-[#27272a] transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => handleSaveModal(editingProvider)}
                className="px-4 py-2 rounded-xl bg-[#fafafa] hover:bg-[#e4e4e7] text-[#09090b] text-xs font-semibold shadow-sm transition-colors cursor-pointer"
              >
                Save Provider
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

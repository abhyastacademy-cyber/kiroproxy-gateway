import React from 'react';
import { Cloud, Lock, Unlock, Server, RefreshCw, Copy, Check, Zap, ShieldCheck } from 'lucide-react';
import type { HealthData, GatewayConfig } from '../types.js';

interface NavbarProps {
  health: HealthData | null;
  config: GatewayConfig | null;
  adminToken: string;
  onOpenSecurityModal: () => void;
  onRefresh: () => void;
  onToggleAutoMode: () => void;
  isRefreshing: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  health,
  config,
  adminToken,
  onOpenSecurityModal,
  onRefresh,
  onToggleAutoMode,
  isRefreshing,
}) => {
  const [copied, setCopied] = React.useState(false);

  const publicUrl = health?.environment.publicUrl ||
    (typeof window !== 'undefined' && (window.location.hostname.includes('ai.studio') || window.location.hostname.includes('run.app'))
      ? 'https://kiroproxy-746899042471.asia-southeast1.run.app'
      : window.location.origin);
  const isCloud = health?.environment.isCloudRun;
  const isAutoModeActive = config?.globalAutoMode !== false;

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(publicUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <header className="border-b border-[#27272a] bg-[#09090b]/95 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#fafafa] text-[#09090b] flex items-center justify-center font-black text-lg font-mono shadow-sm select-none">
            K
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-[#fafafa] text-base tracking-tight">KiroProxy</span>
              <span className="text-[11px] px-2 py-0.5 rounded-full font-mono bg-[#141417] text-zinc-300 border border-[#27272a]">
                Cloud Gateway
              </span>
              {isCloud ? (
                <span className="inline-flex items-center gap-1.5 text-[11px] px-2.5 py-0.5 rounded-full font-medium bg-[#141417] text-zinc-300 border border-[#27272a]" title="Native Cloud Ingress without Ngrok daemon">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <Cloud className="w-3 h-3 text-zinc-400" />
                  <span>Native HTTPS (No Ngrok)</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-[11px] px-2 py-0.5 rounded-full font-medium bg-[#141417] text-zinc-400 border border-[#27272a]">
                  <Server className="w-3 h-3 text-zinc-500" />
                  <span>Port {health?.environment.port || 3000}</span>
                </span>
              )}
            </div>
            <p className="text-xs text-zinc-400">AWS Bedrock &amp; OpenAI Drop-In Reverse Proxy</p>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2.5">
          {/* Global AutoMode / OtoMode Badge */}
          <button
            onClick={onToggleAutoMode}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
              isAutoModeActive
                ? 'bg-[#141417] border-emerald-500/40 text-emerald-400 hover:bg-[#1c1c21] shadow-sm'
                : 'bg-[#141417] border-[#27272a] text-zinc-400 hover:text-[#fafafa] hover:border-[#3f3f46]'
            }`}
            title="Toggle Global AutoMode & OtoMode (Continuous autonomous multi-turn agent execution)"
          >
            <Zap className={`w-3.5 h-3.5 ${isAutoModeActive ? 'text-emerald-400 fill-emerald-400 animate-pulse' : 'text-zinc-500'}`} />
            <span>{isAutoModeActive ? 'AutoMode & OtoMode: ACTIVE' : 'AutoMode: PAUSED'}</span>
          </button>

          {/* Cloud Gateway Native HTTPS Published Domain Pill */}
          <div className="hidden lg:flex items-center gap-2 bg-[#141417] border border-[#27272a] rounded-lg px-3 py-1.5 text-xs">
            <span className="text-zinc-500 font-mono">Gateway:</span>
            <span className="text-[#fafafa] font-mono max-w-[210px] truncate" title={publicUrl}>
              {publicUrl}
            </span>
            <button
              onClick={handleCopyUrl}
              className="p-1 hover:text-[#fafafa] text-zinc-400 transition-colors cursor-pointer"
              title="Copy Native Published HTTPS Gateway URL"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>

          {/* Security Token Button */}
          <button
            onClick={onOpenSecurityModal}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
              adminToken
                ? 'bg-[#141417] border-[#3f3f46] text-[#fafafa] hover:bg-[#1c1c21]'
                : 'bg-[#141417] border-[#27272a] text-zinc-400 hover:text-[#fafafa] hover:border-[#3f3f46]'
            }`}
          >
            {adminToken ? (
              <>
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                <span>Auth Protected</span>
              </>
            ) : (
              <>
                <Unlock className="w-3.5 h-3.5 text-zinc-500" />
                <span>No Auth Token</span>
              </>
            )}
          </button>

          {/* Refresh Button */}
          <button
            onClick={onRefresh}
            disabled={isRefreshing}
            className="p-2 rounded-lg bg-[#141417] hover:bg-[#1c1c21] text-zinc-300 hover:text-white transition-colors border border-[#27272a] cursor-pointer disabled:opacity-50"
            title="Refresh System Health"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-[#fafafa]' : ''}`} />
          </button>
        </div>
      </div>
    </header>
  );
};
